import React from 'react';
import styled from 'styled-components'
import {Link} from 'react-router-dom'

const Nav = styled.div`
    position:fixed;
    z-index:99;
    padding-top: 50px;
    width: 100%;
    color:white;
    font-weight:bold;
    .logo{
        width: 100px;
        margin: 0 auto;
    }
    .depth{
        position:absolute;
        top:50px;
        left: 100px;
        li{ padding: 5px; 0;}
    }
    .registerBox{
        position: absolute;
        right: 70px;
        top:50px;
        a{
            border: 1px solid #fff;
            padding:10px 15px;
            display: block;
        }    
    }
`;

const Header = () => {
    return (
        <Nav>
        <h1 className='logo'><img src="/img/logo.png" alt="x"/></h1>
        <ul className='depth'>
            <li><Link to="/">Our Story</Link></li>
            <li><Link to="/">Location</Link></li>
            <li><Link to="/">Register</Link></li>
        </ul>
        <div className='registerBox'><Link to="/">Register now</Link></div>
        </Nav>
    );
};

export default Header;