import React from 'react';
// import styled from 'styled-components'

const Footer = () => {
    return (
        <div>
            Footer
        </div>
    );
};

export default Footer;