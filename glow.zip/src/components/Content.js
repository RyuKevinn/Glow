import React from 'react';
import {Link} from 'react-router-dom'
import styled from 'styled-components'
import{FaLongArrowAltRight} from 'react-icons/fa'


const ContentBlock =styled.div`
.VideoBox{
    position:relative;
    width:100%;
    height:100vh; 
    overflow:hidden;
    video{
        pointer-events: none;
        min-width:100%;
        min-height:100%;
        position:absolute;
        top:50%;
        left:50%;
        transform:translate(-50%, -50%);
    }
}

    .contentbox{
        >div{
            padding:100px;
        }
        .content1{
            .upbox{
                height:50%;
                display:flex;
                justify-content:space-between;
                .leftbox{
                    align-self:center;
                    width:30%;

                    h1{
                        font-size:45px;
                        margin-bottom:10px;
                    }
                    p{
                        line-height: 25px;
                        padding-bottom:20px;
                    }
                    .rglink{
                        span{
                            position:relative;
                            &::after{
                                content:'';
                                position:absolute;
                                bottom:-5px;
                                left:0;
                                width:100%;
                                height:2px;
                                background:black;
                                transition:all 0.3s;
                            }
                        }
                        &:hover >span::after{
                            width:0;
                        }
                    }
                }
                .rightbox{
                    width: 48%;
                }        
            }
            .downbox{
                padding:70px 0;
            }
        }

        .content2{
            background:#fffaf4;
            // padding:80px;
            .box1{
                margin-bottom:150px;
                display:flex;
                justify-content:space-between;
                .leftbox{
                    width:300px;
                    // border:1px solid black;
                }
                .rightbox{
                    width:60%;
                    align-self:flex-end;
                    ul{
                        
                        li{
                            
                            // border:1px solid #000;
                            font-size: 38px;
                            display:flex;
                            margin-bottom: 60px;
                            .num{
                                margin:10px 30px 0 0;
                                height:60px;
                                padding:0 25px;
                                line-height:55px;
                                font-size: 20px;
                                border:1px solid #000;
                                border-radius: 50%;
                            }
                            .ment{
                                word-break: keep-all;
                                font-weight:normal;
                            }
                        }
                    }
                }
            }
            .box2{
                display:flex;
                justify-content:space-between;
                .leftbox{
                    width:45%;
                    padding-left:100px;
                    overflow:hidden;
                    img{
                        transform:scale(1.1);
                        // height:350px;
                    }
                }
                .rightbox{
                    width:40%;
                    padding-right:200px;
                    h3{
                        margin-bottom:20px;
                    }
                    span{
                        font-size: 25px;
                        line-height:35px;
                    }
                }
            }
        }
        .content3{
            .sendbox{
                padding-top:80px;
                .pbox{
                    h2{
                        font-size:45px;
                        margin-bottom:10px;
                    }
                    p{
                        line-height: 25px;
                        &:last-child{
                            padding-bottom:10px;
                        }
                    }
                }
                .formbox{
                    p{
                        select{
                            height:35px;
                            width:250px;
                            margin-bottom:20px;
                            border:none;
                            border-bottom:1px solid #000;
                            &:first-child{
                                margin-right:20px;
                            }
                            &.long{
                                width:520px;
                            }
                        }
                        input{
                            &.box{
                                height:35px;
                                width:250px;
                                margin-bottom:20px;
                                border:none;
                                border-bottom:1px solid #000;
                                &:first-child{
                                    margin-right:20px
                                }
                            }
                        }
                        label{
                            font-size: 13px;
                            margin:0 20px 0 5px;;
                        }
                        &.checkbox1{
                            margin:10px 0;
                        }
                    }
                    button{
                        margin-top:20px;
                        background: white;
                        border:1px solid black;
                        padding: 10px 20px;
                        .icon{
                            margin-left:15px;
                            font-size:15px;
                            vertical-align:middle;
                        }
                    }
                }
            }
        }
    }
`;


const Content = () => {
    return (
        
        <ContentBlock>
            <div className="VideoBox">
                <video src="/video/intro-video.mp4" title ="비디오"autoPlay="yes" muted="muted" loop="yes"  preload="metadata" controls="no" className="lazy-loaded"></video>
            </div>
            <div className="contentbox">
                <div className='content1'>
                    <div className="upbox">
                        <div className='leftbox'>
                            <h1>Collingwood will soon be home to glow condos</h1>
                            <p>Glow is an iconic new development that marries northern charm with modern luxury. Perfectly placed between the Georgian Bay and Blue Mountains, Glow adds brightness to Collingwood’s most coveted neighbourhood.</p>
                            <Link to="" className='rglink'><span>Register</span> now</Link>
                        </div>
                        <div className='rightbox'>
                            <img src="/img/glow-interior-1.jpg"></img>
                        </div>
                    </div>
                    <div className="downbox">
                        <img src="/img/hero-1.jpg" alt="x"></img>
                        </div>
                </div>
                <div className="content2">
                        <div className='box1'>
                            <div className="leftbox">
                                <p>LARGER THAN LIFE</p>
                            </div>
                            <div className="rightbox">
                                <ul>
                                    <li>
                                        <div className="num">1</div>
                                        <div className="ment">Scenic waterfront views and upscale amenities</div>
                                    </li>
                                    <li>
                                        <div className="num">2</div>
                                        <div className="ment">Unrivalled living overlooking the Georgian Bay</div>
                                    </li>
                                    <li>
                                        <div className="num">3</div>
                                        <div className="ment">A brilliant collection of luxurious suites</div>
                                    </li>
                                    <li>
                                        <div className="num">4</div>
                                        <div className="ment">Masterfully designed to evoke a sense of elegance, simplicity and joy</div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    <div className="box2">
                        <div className="leftbox">
                        <img src="/img/LOBBY_HALL_EXTERIOR_CAM20_crop01_FINAL-min-scaled.jpg" alt="x"></img>
                        </div>
                        <div className="rightbox">
                            <h3>LOCATION</h3>
                            <span>Only a short distance from Blue Mountain, the Collingwood Harbour, several prestigious ski clubs, scenic trails, the Scandinave Spa and seven spectacular golf courses.</span>
                        </div>
                    </div>
                </div>
                <div className="content3">
                    <div className="imgbox">
                        <img src="/img/exterior-img-1.jpg" alt="x"></img>
                    </div>
                    <div className="sendbox">
                        <div className='pbox'>
                            <h2>Register your interest</h2>
                            <p>Be one of the sophisticated few to secure this unique</p>
                            <p>expression of elegant Collingwood living.</p>
                        </div>
                        <form action="" tpye="post" className='formbox'>
                            <p className='typingbox'>
                                <input type="text" placeholder='First Name' className="box"/>
                                <input type="text" placeholder='Last Name' className="box"/>
                            </p>
                            <p className="typingbox">
                                <input type="text" placeholder='Email' className="box"/>
                                <input type="text" placeholder='Phone Number' className="box"/>
                            </p>
                            <p>
                            <select name="" id="" className="box long">
                                <option value="none">How did you hear about us?</option>
                                <option value="Spcoal Media">Spcoal Media</option>
                                <option value="Signage">Signage</option>
                                <option value="Other">Other</option>
                            </select>
                            </p>
                            <p>
                            <select name="" id="" className="box">
                                <option value="none">Select desired square footage</option>
                                <option value="600-1000 sq ft.">600-1000 sq ft.</option>
                                <option value="1000-1500 sq ft.">1000-1500 sq ft.</option>
                                <option value="1500 + sq ft.">1500 + sq ft.</option>
                            </select>
                            <select name="" id="" className="box">
                                <option value="none">Select suite size</option>
                                <option value="1+ den">1+ den</option>
                                <option value="2 bedroom">2 bedroom</option>
                                <option value="3 bedroom">3 bedroom</option>
                            </select>
                            </p>
                            <p className='checkboxtit'>ARE YOU A REALTOR?</p>
                            <p className='checkbox1'>
                                <input type="checkbox" name="yes" id="yes"/>
                                <label >YES</label>
                                <input type="checkbox" name="no" id="no"/>
                                <label >NO</label>
                            </p>
                            <p className="checkbox2">
                                <input type="checkbox" name="no" id="no"/>
                                <label >I CONSENT TO RECEIVING EMAIL</label>
                            </p>
                            
                            <button> Submit <FaLongArrowAltRight className="icon"/></button>
                        </form>
                    </div>
                </div>

            </div>

        </ContentBlock>
    );
};

export default Content;